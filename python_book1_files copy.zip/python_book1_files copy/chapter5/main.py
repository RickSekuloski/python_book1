# import utility
import utility1
from utility import sum_fun, divide_fun, multiply_fun
from utility1 import *
import exponents.pow_of
# import exponents.extra_functions.modulo_fun
from exponents.extra_functions.modulo_fun import modulo_fn
import unnecessary_long_module_name as long_module
num1 = 6
num2 = 3

# the following 6 lines are if we use: import utility statement
# sum_result = utility.sum_fun(num1, num2)
# divide_result = utility.divide_fun(num1, num2)
# multiply_result = utility.multiply_fun(num1, num2)
# print(sum_result)
# print(divide_result)
# print(multiply_result)

# new from-import syntax
print(sum_fun(num1, num2))
print(divide_fun(num1, num2))
print(multiply_fun(num1, num2))

print(exponents.pow_of.pow_fun(num1))

# instead of using this long syntax
# print(exponents.extra_functions.modulo_fun.modulo_fn(num1, num2))
# we can use modulo_fn
print(modulo_fn(num1, num2))


print(utility1.sum_fun1(num1, num2))
print(utility1.divide_fun1(num1, num2))
print(utility1.multiply_fun1(num1, num2))

print(long_module.greet('Kevin Hart'))
