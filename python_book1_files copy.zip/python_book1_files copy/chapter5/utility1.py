def sum_fun1(num1, num2):
    return num1 + num2


def divide_fun1(num1, num2):
    return num1 / num2


def multiply_fun1(num1, num2):
    return num1 * num2


