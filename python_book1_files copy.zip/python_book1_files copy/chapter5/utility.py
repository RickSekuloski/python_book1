def sum_fun(num1, num2):
    return num1 + num2


def divide_fun(num1, num2):
    return num1 / num2


def multiply_fun(num1, num2):
    return num1 * num2


