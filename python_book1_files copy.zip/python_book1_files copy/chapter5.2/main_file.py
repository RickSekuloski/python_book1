import math


print(dir(math))

print(math.log(2.35657))
print(math.log(3))
print(math.log(1))

print(math.pow(3, 3))

print(math.sqrt(9))
print(math.sqrt(25))
print(math.sqrt(16))

