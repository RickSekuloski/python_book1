import random

the_number = random.randint(1, 10)

player = input('Hello stranger what is your name? \n>')
print(f'Excellent {player}! Can you try and guess a number between 1 and 10:')
player_number = int(input(''))

number_of_guesses = 1
while number_of_guesses < 3:
    number_of_guesses += 1
    if player_number < the_number:
        print(f'The number we are looking is greater than {player_number}')
        player_number = int(input(''))
    if player_number > the_number:
        print(f'The number we are looking is smaller than {player_number}')
        player_number = int(input(''))
    if player_number == the_number:
        break

if player_number == the_number:
    if number_of_guesses == 1:
        print(f'You guessed the number in your {number_of_guesses}-st attempt!')
    elif number_of_guesses == 2:
        print(f'You guessed the number in your{number_of_guesses}-nd attempt')
    else:
        print(f'You guessed the number in your {number_of_guesses}-rd attempt!')

else:
    print(f'The number we were looking was {the_number}')
