# inheritance
class Person:
    # Constructor
    def __init__(self, name='John', lastname='Doe', age=18):
        if age >= 18:
            self._name = name  # name attribute
            self._lastname = lastname  # lastname attribute
            self._age = age  # age attribute

    # Method
    def greet(self):
        print(f'The data and functions are encapsulated, \n'
              f'My name is: {self._name},\n'
              f'My last name: {self._lastname},\n'
              f'and I\' old:{self._age} ')


print('------- Person Class ------')

person_obj1 = Person('Jason', 'Mamoa', 53)
person_obj1.greet()


class Student(Person):
    def __init__(self, name, lastname, age, dob, address):
        Person.__init__(self, name, lastname, age)
        self.dob = dob
        self.address = address

    # Method overriding
    def greet(self):
        print(f'My name is: {self._name},\n'
              f'My last name: {self._lastname},\n'
              f'and I\' old:{self._age}. I\'m student: \n'
              f'born at: {self.dob},\n'
              f'that lives in : {self.address}')


print('------- Student Class ------')

student_obj1 = Student('Rick', 'Jameson', 33, '29/09/1987', 'Melbourne/Australia')

print(student_obj1.greet())
