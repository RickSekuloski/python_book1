class Person:
    # Class Object Attribute
    is_person = True

    # Constructor
    def __init__(self, name='John', lastname='Doe', age=18):
        if (age >= 18):
            self.name = name  # name attribute
            self.lastname = lastname  # lastname attribute
            self.age = age  # age attribute

    # Method
    def greet(self):
        print(f'{self.name}, '
              f'{self.lastname}, old:{self.age} '
              f'{Person.is_person},'
              f'{self.is_person}')
    # Class Method
    @classmethod
    def date_created(cls,today_date,year):
        print(today_date,year)


# person_obj1 = Person('Jason', 'Brooks', 16)
# print(person_obj1)
# print(person_obj1.name)
# person_obj2 = Person('Andy', 'Garcia', 20)
# print(person_obj2.name)
# person_obj3 = Person()
# print(person_obj3.name)
#
# person_obj3.date_created('14/05',2023)
Person.date_created('12/12',2023)
print(Person.is_person)