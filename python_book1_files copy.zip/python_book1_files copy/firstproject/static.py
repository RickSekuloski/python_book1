# static method
class Person:
    # Class Object Attribute
    is_person = True

    # Constructor
    def __init__(self, name='John', lastname='Doe', age=18):
        if age >= 18:
            self.name = name  # name attribute
            self.lastname = lastname  # lastname attribute
            self.age = age  # age attribute

    # Method
    def greet(self):
        print(f'{self.name}, '
              f'{self.lastname}, old:{self.age} '
              f'{Person.is_person},'
              f'{self.is_person}')

    # Static Method
    @staticmethod
    def is_adult(age):
        return age >= 18


person_obj1 = Person('Jason','Mamoa',53)
print(Person.is_adult(19))
