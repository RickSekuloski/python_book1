# encapsulation
class Person:

    # Constructor
    def __init__(self, name='John', lastname='Doe', age=18):
        if age >= 18:
            self.name = name  # name attribute
            self.lastname = lastname  # lastname attribute
            self.age = age  # age attribute

    # Method
    def greet(self):
        print(f'The data and functions are encapsulated, \n'
              f'My name is: {self.name},\n'
              f'My last name: {self.lastname},\n'
              f'and I\' old:{self.age} ')


person_obj1 = Person('Jason', 'Mamoa', 53)
person_obj1.greet()
