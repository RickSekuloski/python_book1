#private and public variables
class Person:

    # Constructor
    def __init__(self, name='John', lastname='Doe', age=18):
        if age >= 18:
            self._name = name  # name attribute
            self._lastname = lastname  # lastname attribute
            self._age = age  # age attribute

    # Method
    def greet(self):
        print(f'The data and functions are encapsulated, \n'
              f'My name is: {self._name},\n'
              f'My last name: {self._lastname},\n'
              f'and I\' old:{self._age} ')


person_obj1 = Person('Jason', 'Mamoa', 53)
person_obj1.greet()
person_obj1.name = 'Carson'
person_obj1.greet()
