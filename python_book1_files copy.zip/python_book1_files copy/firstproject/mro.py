# MRO - Method Resolution Order

# class A

class A:
    def __init__(self, length=5):
        self.length = length

    def info(self):
        return self.length


class B(A):
    pass


class C(A):
    def __init__(self, length=2):
        self.length = length

    def info(self):
        return self.length


class D(B, C):
    pass


# instance of class D
d_ob1 = D()
print(d_ob1.info())
print(D.mro())


class First:
    pass


class Second:
    pass


class Third:
    pass


class Fourth(First, Second):
    pass


class Fifth(Second, Third):
    pass


class Sixth(Fifth, Fourth, Third):
    pass


print(Sixth.mro())