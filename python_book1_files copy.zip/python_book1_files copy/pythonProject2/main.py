from login import teacher_login
from register import teacher_register
from student_tasks import get_student_scores, update_student_score, add_new_student

teacher_selection = 0

while teacher_selection != 3:
    print(f'Welcome to Teacher Panel \n'
          f'What do you want to do (select a number): \n'
          f'1) Login\n'
          f'2) Register\n'
          f'3) Exit\n'
          f'Select a number \n'
          f'>')
    teacher_selection = int(input(''))
    if teacher_selection == 2:
        print('************** Teacher Registration  **************  \n')
        print('Your first name')
        teacher_name = input('')
        print('Your last name')
        teacher_lastname = input('')
        print('Your login password')
        teacher_password = input('')
        teacher_register(teacher_name, teacher_lastname, teacher_password)
    elif teacher_selection == 1:
        print('************** Teacher Login  **************  \n')
        print('User Name')
        teacher_username = input('')
        print('Your Password')
        teacher_password = input('')
        login_result = teacher_login(teacher_username, teacher_password)

        while login_result != -1:
            print(f'Welcome back teacher {teacher_username} \n'
                  f'What you want to do (select a number): \n'
                  f'1) Get Student Scores \n'
                  f'2) Update Student Score \n'
                  f'3) Enroll New Student \n'
                  f'4) Exit \n'
                  f'>')
            teacher_login_input = int(input(''))
            if teacher_login_input == 4:
                break
            if teacher_login_input == 1:
                print(get_student_scores())
            elif teacher_login_input == 2:
                print('Input student details')
                print('Student name')
                student_name = input('')
                print('New student score')
                student_score = int(input(''))
                update_student_score(student_name, student_score, teacher_username)

            elif teacher_login_input == 3:
                print('Enroll new student')
                print('Student name')
                student_name = input('')
                print('Student score')
                student_score = int(input(''))
                add_new_student(student_name, student_score, teacher_username)
            else:
                print('You have entered a wrong choice')
