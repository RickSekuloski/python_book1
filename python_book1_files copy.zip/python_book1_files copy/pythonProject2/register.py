import bcrypt


# register new teacher
def teacher_register(user_name, user_lastname, password):
    # try - except block
    try:
        password_hashed = hash_password(password)
        with open('teachers.txt', mode='a') as new_text_file:
            new_text_file.write(f'{user_name}, {user_lastname}, {password_hashed}, \n')
        return f'{user_name} , Your registration is successful, go back and log in!'
    except FileNotFoundError as err:
        print('File cannot be found!')


# hashing function
def hash_password(user_password):
    # encode the password
    bytePwd = user_password.encode('utf-8')
    # Generate salt
    mySalt = bcrypt.gensalt()
    # Hash password
    user_password_hashed = bcrypt.hashpw(bytePwd, mySalt)
    return user_password_hashed

