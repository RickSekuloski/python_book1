from os import remove, rename
from datetime import datetime


def get_student_scores():
    try:
        with open('student_scores.txt', mode='r') as students:
            return students.read()
    except FileNotFoundError as err:
        print('File cannot be found!')


def update_student_score(student_name, student_score, teacher_username):
    try:
        now = datetime.now()
        date_time = now.strftime("%m/%d/%Y, %H:%M:%S")
        tmp = open('student_scores.tmp', mode='w')
        original_file = open('student_scores.txt', mode='r')
        for line in original_file:
            content = line.split(', ')
            if student_name in content:
                tmp.write(f'{student_name}, {student_score}, Updated by Teacher:{teacher_username}, {date_time}\n')
            else:
                tmp.write(line)
        tmp.close()
        original_file.close()
        remove('student_scores.txt')
        rename('student_scores.tmp', 'student_scores.txt')

    except FileNotFoundError as err:
        print('File cannot be found!')


def add_new_student(student_name, student_score, teacher_username):
    try:
        now = datetime.now()
        date_time = now.strftime("%m/%d/%Y, %H:%M:%S")
        with open('student_scores.txt', mode='a') as new_text_file:
            new_text_file.write(
                f'{student_name}, {student_score}, Added by Teacher {teacher_username} at:, {date_time}')
            print(f'Student with the {student_name} successfully added in the system ')
    except FileNotFoundError as err:
        print('File cannot be found!')









