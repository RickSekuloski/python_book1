import bcrypt


def teacher_login(user_name, password):
    new_password = password.encode('utf-8')
    try:
        with open('teachers.txt', mode='r') as teachers:
            for teacher in teachers:
                result = teacher.split(', ')
                if user_name in result:
                    striped_string = result[2][2:-1]
                    if bcrypt.checkpw(new_password, striped_string.encode('utf-8')):
                        return True

            print(f'Sorry you are not registered as a teacher \n'
                  f'please contact the administration for access')
            return -1

    except FileNotFoundError as err:
        print('File cannot be found!')

