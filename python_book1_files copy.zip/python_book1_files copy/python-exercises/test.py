# class template
class StudentObj:
    pass


# create new object by instantiate the StudentObj class
s_obj1 = StudentObj()

print(type(s_obj1))
