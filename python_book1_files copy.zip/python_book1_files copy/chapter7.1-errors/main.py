
# 1 SyntaxError
# print(')'

# 2 TypeError
# print(1 + '2')
#
# if 5 > 3:
#     print('5 is bigger than 3')

# 3 NameError
# result = 1 + two

# 4 IndexError
# list_ob = [1, 2, 3, 4]
# print(list_ob[3])
# print(list_ob[4])

# 5 KeyError

# car_dict = {
#     'car': 'Ford',
#     'model': 'Mustang',
#     'engine': '5.0',
# }
#
# print(car_dict['car'])
# print(car_dict['Model'])

# 6 ZeroDivisionError
print(3 / 0)
