# Error Handling finally

try:
    number = int(input('Enter a number:_ '))
    number >= 3
except (TypeError, ValueError) as err:
    print(f'Something went wrong: {err}')
else:
    print(f'Everything is ok and the result'
          f' is {number * 3}')
finally:
    print("The try-except block is finished")










