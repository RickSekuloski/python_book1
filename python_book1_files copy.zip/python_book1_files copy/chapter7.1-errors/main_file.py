# Error Handling
from datetime import date
current_year = date.today().year

while True:
    try:
        dob = int(input('Enter year of birth: '))
        print(current_year - dob)
        print(current_year / dob)
    except ValueError as err:
        print('You have entered invalid value, please'
              ' enter a valid number!')
    except ZeroDivisionError as err:
        print('The age should not be zero!')
    else:
        break


print('This is printed after while loop!')
