# Error Handling

def div_numbers(a, b):
    try:
        return a / b
    # except TypeError as err:
    #     print(f'Make sure the operands are numbers {err}')
    except (TypeError, ZeroDivisionError) as err:
        print(f'We got an error: {err}')


# result = div_numbers(10, '2')
result = div_numbers(10, 0)
print(result)
