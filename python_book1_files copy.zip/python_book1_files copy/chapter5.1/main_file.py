from utility import sum_fun, divide_fun, multiply_fun
import exponents.pow_of
from exponents.extra_functions.modulo_fun import modulo_fn


if __name__ == '__main__':
    num1 = 6
    num2 = 3

    print(sum_fun(num1, num2))
    print(divide_fun(num1, num2))
    print(multiply_fun(num1, num2))

    print(exponents.pow_of.pow_fun(num1))

    print(modulo_fn(num1, num2))

    print(__name__)


