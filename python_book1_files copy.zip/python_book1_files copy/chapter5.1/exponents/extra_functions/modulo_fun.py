def modulo_fn(num1, num2):
    return num1 % num2
