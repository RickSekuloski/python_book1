print(__name__)


def pow_fun(num):
    return num ** 2
