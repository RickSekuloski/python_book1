import pyjokes

joke = pyjokes.get_joke()

print('====== Joke ======')
print(joke)
