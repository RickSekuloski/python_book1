# import the teacher_login function from login

# import teacher_register from register

# import get_student_scores, update_student_score, add_new_student from student_tasks


# this variable will make main menu to appear
# as long as the while loop is evaluated to true
# the while loop will stop when user selects number 3
teacher_selection = 0

while teacher_selection != 3:
    print(f'Welcome to Teacher Panel \n'
          f'What do you want to do (select a number): \n'
          f'1) Login\n'
          f'2) Register\n'
          f'3) Exit\n'
          f'Select a number \n'
          f'>')
    teacher_selection = int(input(''))
    if teacher_selection == 2:
        print('************** Teacher Registration  **************  \n')
        print('Your first name')
        teacher_name = input('')
        print('Your last name')
        teacher_lastname = input('')
        print('Your login password')
        teacher_password = input('')
        # call the teacher_register() function with 3 arguments
    elif teacher_selection == 1:
        print('************** Teacher Login  **************  \n')
        print('User Name')
        teacher_username = input('')
        print('Your Password')
        teacher_password = input('')
        # call the teacher_login function with 2 arguments
        # store the result of teacher_login in the variable bellow login_result
        login_result = 0

        while login_result != -1:
            print(f'Welcome back teacher {teacher_username} \n'
                  f'What you want to do (select a number): \n'
                  f'1) Get Student Scores \n'
                  f'2) Update Student Score \n'
                  f'3) Enroll New Student \n'
                  f'4) Exit \n'
                  f'>')
            teacher_login_input = int(input(''))
            if teacher_login_input == 4:
                break
            if teacher_login_input == 1:
                pass
                # delete the pass statement above
                # use the print function to print the get_student_scores() data

            elif teacher_login_input == 2:
                print('Input student details')
                print('Student name')
                student_name = input('')
                print('New student score')
                student_score = int(input(''))
                # call the update_student_score with 3 arguments
                # As arguments use the variables declared above
                # from the user input
                # don't forget the teacher_username should be the last
                # variable


            elif teacher_login_input == 3:
                print('Enroll new student')
                print('Student name')
                student_name = input('')
                print('Student score')
                student_score = int(input(''))
                # call add_new_student function with 3 arguments
                # remember the last argument is the teacher_username

            else:
                print('You have entered a wrong choice')
