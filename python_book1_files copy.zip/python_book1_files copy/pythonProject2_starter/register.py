import bcrypt


# register new teacher using user_name, user_lastname and password
def teacher_register(user_name, user_lastname, password):
    # try - except block
    try:
        # here you will need to call the hash_password()
        # function that will return
        # a password that is hashed using bcrypt.
        # You don't need to know about the hash_password()
        # function at the moment just follow the instructions:
        # 1-st) Pass the password parameter in the hash_password(password).
        # 2-nd) Store whatever is returned from the above function
        # in a variable called password_hashed

        with open('teachers.txt', mode='a') as new_text_file:
            pass
            # Delete pass.
            # use the new_text_file to write to the teachers.txt file
            # Remember you need to follow the following format:
            # user_name, last_name, password_hashed, \n
        # when you are done writing to teachers.txt file return a formatted
        # string like this:
        # f'{user_name} , Your registration is successful, go back and log in!'
        # Make sure the return is not in the with open block.
    except FileNotFoundError as err:
        print('File cannot be found!')


# hashing function to hash the above password
def hash_password(user_password):
    # encode the password
    bytePwd = user_password.encode('utf-8')
    # Generate salt
    mySalt = bcrypt.gensalt()
    # Hash password
    user_password_hashed = bcrypt.hashpw(bytePwd, mySalt)
    return user_password_hashed

