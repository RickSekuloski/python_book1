# import bcrypt, if you have installed the bcrypt
# package the import bcrypt will not cause errors
import bcrypt

# login function that have 2 parameters the
# teacher name and password
def teacher_login(user_name, password):
    # encode method returns an encoded version of the given string.
    # if you read the bcrypt documentation we need the string
    # to be encoded in order to be hashed or verified
    new_password = password.encode('utf-8')
    try:
        pass
        # Delete the above pass statement.
        # In the try-except block you need to try
        # to open the teachers.txt file using the mode-r
        # example:

        # with open('teachers.txt', mode='r') as teachers:

        # use for-in loop to loop through all
        # the lines in the teachers.txt file.
        # At the moment there is only one, but
        # if there are more teachers registered
        # the teachers.txt file will contain multiple
        # lines.
        # Important you can use split() method that will
        # split the string into a list
        # the syntax is split(separator, maxsplit)
        # This is the hardest function here is a
        # helper code:

        # for teacher in teachers:
        #     result = teacher.split(', ')

        # After this you need to find if the teacher
        # with the user_name passed as parameter exists
        # in one of the lines. You can use the
        # keyword 'in' to check if the user_name
        # can be found in one of the lines.
        # If the user is found then the password that
        # is passed and encoded matches
        # the hashed password stored in the file.
        # For this you will need to use the
        # bcrypt.checkpw method that will compare
        # the passed password with the hashed password from
        # teachers.txt file
        # If there is not a match of the user_name
        # this means the teacher is not registered
        # so print the following message:
        # print(f'Sorry you are not registered as a teacher \n'
        #       f' please contact the administration for access')
        # and after the print message use the return statement to
        # return -1


    except FileNotFoundError as err:
        print('File cannot be found!')

