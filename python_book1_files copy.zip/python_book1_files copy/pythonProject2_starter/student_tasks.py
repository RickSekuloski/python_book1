from os import remove, rename
from datetime import datetime

# get the student scores
def get_student_scores():
    try:
        with open('student_scores.txt', mode='r') as students:
            pass
        # you can use the simple read() function to return
        # all the students like we did in the book.

    except FileNotFoundError as err:
        print('File cannot be found!')

# function to update the user score based on 3 parameters
def update_student_score(student_name, student_score, teacher_username):
    try:
        # to create the timestamp I have used:
        # now = datetime.now()
        # and date_time = now.strftime("%m/%d/%Y, %H:%M:%S")
        # If you like to create something different you are welcome
        # to try
        # instead of nested with open I have used the old open method
        # but we need to close it at the end
        # tmp is for the temporary file with mode write
        tmp = open('student_scores.tmp', mode='w')
        # open the original file with read mode
        original_file = open('student_scores.txt', mode='r')
        # The idea is to update the student_score in a new file
        # and then to rename the temporary file with the changes
        # as the orginal file
        for line in original_file:
            content = line.split(', ')
            if student_name in content:
                pass
                # Delete the pass statement.
                # If the student_name is found in the content then
                # we need to write whatever we have from original file
                # into the temporary file using the tmp.write()
                # f'{student_name}, {student_score}, Updated by Teacher:{teacher_username}, {date_time}\n'
            else:
                pass
                # delete the pass
                # we can write the entire line in the tmp file
        # we need to close the tmp and original_file
        # next is to remove the student_scores.txt using the remove function
        # next is to rename the student_scores.tmp to student_scores.txt


    except FileNotFoundError as err:
        print('File cannot be found!')


update_student_score('Ann', 765, 'Rick')


def add_new_student(student_name, student_score, teacher_username):
    try:
        pass
        # Delete the pass statement above
        # use the now and date_time from the function above

        with open('student_scores.txt', mode='a') as new_text_file:
            pass
            # Delete the pass above
            # write to file using the write function the following string:
            #f'\n{student_name}, {student_score}, Added by Teacher {teacher_username} at:, {date_time}'
            # print message f'Student with the {student_name} successfully added in the system '

    except FileNotFoundError as err:
        print('File cannot be found!')
