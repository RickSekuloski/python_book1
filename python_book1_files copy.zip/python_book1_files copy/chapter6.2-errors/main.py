# try - except block
try:
    with open('readme1.txt', mode='r') as new_text_file:
        print(new_text_file.read())

except FileNotFoundError as err:
    print('File cannot be found!')
    raise err
except IOError as err1:
    print('IOError!')
    raise err1
