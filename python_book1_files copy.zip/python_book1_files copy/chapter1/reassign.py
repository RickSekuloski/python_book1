# reassign values to variables
num1 = 10
print(num1)

# give num1 value of 13.4
num1 = 13.4
print(num1)

# initialize a variable
my_weight = 78
# reasing
your_weight = my_weight - 10
print(your_weight)
