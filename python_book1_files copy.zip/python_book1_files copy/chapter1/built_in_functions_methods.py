# 1) lin() -returns the lenght
text = 'A string'
print(len(text))

# String methods
# upper()
result = text.upper()
print(result)

# capitalize()
print('hi there'.capitalize())

# lower()
print('My Name Is Joshua'.lower())

# find()
result = 'My name is Rick, what is yours'.find('is')
print(result)

# replace()
# result = 'My name is Rick, what is yours'.replace('Rick', 'Mick')
# print(result)

original_string = 'My name is Rick, what is yours'
result = original_string.replace('Rick', 'Mick')
print(original_string)
print(result)

# join()
result = "-".join(["This", "book", "is", "awesome!"])
print(result)
