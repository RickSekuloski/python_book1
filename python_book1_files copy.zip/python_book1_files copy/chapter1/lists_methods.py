# list methods

# 1 append
my_list = ['one', 'two', 'three']
my_list.append('four')
print(my_list)

# 2 insert
my_list.insert(4, 'five')
print(my_list)

# 3 extend
my_list.extend(['six', 'seven'])
print(my_list)

# 4 pop
my_list.pop()
print(my_list)
# remove the first item
my_list.pop(0)
print(my_list)

# 5 remove
my_list.remove('four')
print(my_list)

# 6 clear
my_list.clear()
print(my_list)


# new list
new_list = ['one', 'two', 'three', 'four', 'five']
# 7 index
print(new_list.index('three'))

# index method with 3 params
print(new_list.index('three', 0, 3))

# error if the range is not correct
print(new_list.index('three', 0, 2))

# 8 count
my_list1 = ['one', 'two', 'three', 'one', 'four']
print(my_list1.count('one'))

# 9 sort
numbers_list = [3, 6, 7, 1, 5, 2, 4]
numbers_list.sort()
print(numbers_list)

# sorted() function not a method
numbers_list1 = [3, 6, 7, 1, 5, 2, 4]
store_sorted = sorted(numbers_list1)
print(numbers_list1)
print(store_sorted)

# 10 copy
numbers_list = [3, 6, 7, 1, 5, 2, 4]
new_list = numbers_list.copy()
print(new_list)

# 11 reverse
numbers_list2 = [3, 6, 7, 1, 5, 2, 4]
numbers_list2.reverse()
print(numbers_list2)

# combining different list methods
numbers_list3 = [3, 6, 7, 1, 5, 2, 4]
numbers_list3.sort()
numbers_list3.reverse()
print(numbers_list3)
