# tuples
new_tuple = (1, 2, 3)

# access items
print(new_tuple[2])

# modify tuples
# new_tuple[2] = 4
# print(new_tuple)

# length
print(len(new_tuple))

# slicing tuples
new_tuple = (1, 2, 3, 4)
new_tuple1 = new_tuple[0:2]
print(new_tuple1)

# tuples unpacking
new_tuple = (1, 2, 3, 4, 6)
a, b, c, *rest = new_tuple

print(a)
print(b)
print(c)
print(rest)

# modify the last rest item because it is a list
rest[1] = 7
print(rest)


# tuple methods

# count
new_tuple = (1, 2, 3, 4, 5, 6, 1)
print(new_tuple.count(1))

# index
print(new_tuple.index(3))
print(new_tuple.index(1))
