print('Hi everyone!')
name = input('What is your name? ')
print(name)
name = 'Jason'
print(name)
my_age = 10

# multiple varibales in one line
first, second = 1, 2
print(first)
print(second)

# single line comment with # sing in front of line
'''
Hi,
this is multi-
line comment!
'''
