# In Keyword with Strings
long_string = 'Andy is 5 years old!'
print('5' in long_string)
