
# math functions
# 1 round()
print(round(4.1))
print(round(4.2))
print(round(4.3))
print(round(4.4))
print(round(4.5))
print(round(4.6))
print(round(4.76000))
print(round(4.8))
print(round(4.9))

# 2 abs()
print(abs(-10))
print(abs(-11.2344))
