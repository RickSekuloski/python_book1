# Int
a = 6
b = 3
print(a + b)
print(a * b)
print(a / b)
print(a - b)
# check the type
print(type(a))
print(type(b))

# Float
m = 1.5
n = 3.22
print(m * n)
print(type(m))
print(type(n))

# bin
print(bin(2))
