# Boolean True or False
is_true = True
print(is_true)

is_false = False
print(is_false)

# compare values
print(2 > 1)
print(10 == 10)
print(10 < 6)

# bool
print(bool(0))
print(bool(1))
