# two_dimensional lists
# two-dimensional lists
two_dimensional = [
    [1, 2, 3],
    [3, 4, 5]
]
# the two lists
print(two_dimensional[0])
print(two_dimensional[1])
# first inner list elements
print('First Inner List Items')
print(two_dimensional[0][0])
print(two_dimensional[0][1])
print(two_dimensional[0][2])
print('Second Inner List Items')
# second inner list elements
print(two_dimensional[1][0])
print(two_dimensional[1][1])
print(two_dimensional[1][2])
