this_dictionary = {
    "car": "Ford",
    "model": "Mustang",
    "year": 1964
}
print(this_dictionary)

# value Ford
print(this_dictionary["car"])


# dictionary with different data types as values
this_dictionary1 = {
    "car": True,
    "brands": ['Ford', 'Toyota', 'BMW'],
    "year": 2022
}
print(this_dictionary1['brands'][1])


# lists with dictionary as data type
new_list = [
    {
        "car": True,
        "brands": ['Ford', 'Toyota', 'BMW'],
        "year": 2022
    },
    {
        "car": False,
        "brands": ['Ranger', 'Kluger', 'X5'],
        "year": 2022
    }
]

# access the first element of the list
print(new_list[0])
# get the value of the car
print(new_list[0]['car'])
# get the car brands
print(new_list[0]['brands'])

# second way of creating new dictionary
new_dict = dict(car='Tesla')
print(new_dict)
