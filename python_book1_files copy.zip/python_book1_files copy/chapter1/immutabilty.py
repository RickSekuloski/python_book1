# String immutability
my_text = 'Strings are immutable'
print(my_text)
my_text = 'New text'
print(my_text)
print(my_text[0])
# this will not work
# my_text[0] = 'K'
print(my_text)
