# Escape sequence
text = 'I\'m Rick'
print(text)
text1 = "I'm Rick"
print(text1)

# \
text2 = 'James\\Oliver\\Thomas\\Theodore'
print(text2)

# tab
text3 = 'Without a tab'
text4 = '\t With a tab'
print(text3)
print(text4)

# newline
your_name = '\t I\'m Rick \\ who\'re \n you?'
print(your_name)

# double quotes
text5 = "He said \"This is hard\", and I believe him"
print(text5)
