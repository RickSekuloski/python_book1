# Sets
new_set = {1, 2, 3, 4, 5, 6, 7}
print(new_set)

# duplicates will be removed
new_set = {1, 2, 3, 4, 5, 6, 7, 1}
print(new_set)

# accessing Set Items
new_set = {1, 2, 3, 4, 5, 6, 7, 6}
# print(new_set[0]) # error

# ask for item using the 'in' Python keyword
print(7 in new_set)

# length of a set
print(len(new_set))

# create a Set from a List using the set() function
new_list = [1, 2, 3, 1, 5, 4, 5, 6, 7, 6]
new_set = set(new_list)
print(new_set)

# convert Set to a List
new_set = {1, 2, 3, 4, 5, 6, 7, 7}
new_list = list(new_set)
print(new_list)

# Sets methods

# copy() method
new_set = {1, 2, 3, 4, 5, 6, 7, 7}
new_set1 = new_set.copy()
print(new_set1)


# difference() method
new_set = {1, 2, 3, 4, 5, 6, 7}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
print(new_set.difference(new_set1))

# difference_update() method
new_set = {1, 2, 3, 4, 5, 6, 7}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
new_set.difference_update(new_set1)
print(new_set)


# discard() method
new_set = {1, 2, 3, 4, 5, 6, 7}
new_set.discard(7)
print(new_set)

# intersection method
new_set = {1, 2, 3, 4, 5, 6, 7}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
print(new_set.intersection(new_set1))
# same can be achieved if we use the & symbol
# print(new_set & new_set1)

# intersection_update method
new_set = {1, 2, 3, 4, 5, 6, 7}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
new_set.intersection_update(new_set1)
print(new_set)

# isdisjoint() method
new_set = {1, 2, 3, 4, 5, 6, 7}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
print(new_set.isdisjoint(new_set1))

# isdisjoint() true
new_set = {1, 2, 3, 4}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
print(new_set.isdisjoint(new_set1))


# union method
new_set = {1, 2, 3, 4, 5, 6, 7}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
print(new_set.union(new_set1))
# the same result
print(new_set | new_set1)

# issubset()
new_set = {5, 6, 7}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
print(new_set.issubset(new_set1))

# issubset() that returns false
new_set = {1, 2, 3, 4, 5, 6, 7}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
print(new_set.issubset(new_set1))

# issuperset()
new_set = {5, 6, 7}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
print(new_set.issuperset(new_set1))

# issuperset() true
new_set = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}
new_set1 = {5, 6, 7, 8, 9, 10, 11}
print(new_set.issuperset(new_set1))
