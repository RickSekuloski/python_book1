# Augmented assignment operator
num1 = 30
num2 = 10
# Addition & Assignment
num1 += num2
print(num1)

num1 = 30
num2 = 10
# Subtraction & Assignment
num1 -= num2
print(num1)

num1 = 30
num2 = 10
# Multiplication & Assignment
num1 *= num2
print(num1)

num1 = 30
num2 = 10
# Division & Assignment
num1 /= num2
print(num1)

num1 = 30
num2 = 10
# Floor Division & Assignment
num1 //= num2
print(num1)

num1 = 30
num2 = 10
# Power  & Assignment
num1 **= num2
print(num1)

num1 = 30
num2 = 10
# Modulen & Assignment
num1 %= num2
print(num1)
