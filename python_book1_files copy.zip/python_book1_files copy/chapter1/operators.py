# power-operator **
print(2 ** 3)
print(5 ** 2)
print(3 ** 3)

# Python Double Slash (//) Operator: Floor Division
print(5 // 4)

# Modulo operator
print(5 % 4)
