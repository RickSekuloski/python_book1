# f-strings to format the strings
first_name = 'James'
last_name = 'Bond'
age = 55

print(f'Dear {first_name} {last_name}, thank you for being 007 for so many years!')

# the equivalent using the string concatenation
print('Dear ' + first_name + ' ' + last_name +
      ', thank you for being 007 for so many years!')
