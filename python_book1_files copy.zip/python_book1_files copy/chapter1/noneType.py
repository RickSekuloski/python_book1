# None Keyword and Data Type
no_value = None
print(no_value)
print(type(no_value))
