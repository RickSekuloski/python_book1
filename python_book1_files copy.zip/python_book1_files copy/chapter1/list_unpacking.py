# list unpacking
andy, carol, steve, jason = ['andy', 'carol', 'steve', 'jason']
print(andy)
print(carol)
print(steve)
print(jason)

# rest syntax
andy, carol, *rest = ['andy', 'carol', 'steve', 'jason']
print(andy)
print(carol)
print(rest)
