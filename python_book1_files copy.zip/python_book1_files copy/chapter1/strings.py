# Str - strings data type
my_name = 'Keanu'
my_lastname = "Reeves"
print(my_name)
print(my_lastname)

# check the data type
print(type(my_name))
print(type(my_lastname))

# long string
text = '''
first line
second line
third line
'''
print(text)

# String Concatenation
full_name = my_name + my_lastname
print(full_name)

# cannot concatenate str to int
greet = 'hi'
five = 5
message = greet + five
print(message)
