# String Indexes
my_name = 'Rick S'
print(my_name[0])
print(my_name[4])
# print(my_name[6])

# substring
print(my_name[0:4])
# full string
print(my_name[0:6])

# Step over
number_string = '012345678'
print(number_string[0:9:2])

print(number_string[1:])
print(number_string[:4])
print(number_string[::1])
print(number_string[::2])

# negaive values
print(number_string[-1])
# to reverse the string character order
print(number_string[::-1])
