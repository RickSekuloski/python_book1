this_dictionary1 = {
    "car": True,
    "brands": ['Ford', 'Toyota', 'BMW'],
    "year": 2022
}
print('year' in this_dictionary1)
print(2022 in this_dictionary1)

# get method
print(this_dictionary1.get('car'))

# get method returns None when key is not found
print(this_dictionary1.get('cars'))

# get method with second parameter known as value
print(this_dictionary1.get('cars', ['ford', 'audi']))

# keys method
print(this_dictionary1.keys())

# find a key from the view object
print('car' in this_dictionary1.keys())

# values method
print(this_dictionary1.values())

# items method
print(this_dictionary1.items())

# clear method
print(this_dictionary1.clear())
print(this_dictionary1)

# copy method
this_dictionary2 = {
    "car": True,
    "brands": ['Ford', 'Toyota', 'BMW'],
    "year": 2022
}
dict_copy = this_dictionary2.copy()
print(dict_copy)

# pop method
print(this_dictionary2.pop('year'))
print(this_dictionary2)

# popitem
this_dictionary2.popitem()
print(this_dictionary2)

# update
print(this_dictionary2.update({'year': 2023}))
print(this_dictionary2)

# setdefault
year = this_dictionary2.setdefault('year')
print(year)
