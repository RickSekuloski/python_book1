# type conversion
result = str(250)
print(result)
print(type(result))
# can only concatenate str (not "int") to str
print(result + 10)

# type conversion from string to int
num0 = str(5)
print(type(num0))
num2 = 10
num1 = int(num0)
print(type(num1))
result1 = num1 + num2
print(result1)

# implicit type conversion
int_number1 = 12
flo_number2 = 12.456
print("data type of integer:", type(int_number1))
print("data type of flolat:", type(flo_number2))
sum_numbers = int_number1 + flo_number2
print("Value of num_new:", sum_numbers)
print("data type of the sum:", type(sum_numbers))
