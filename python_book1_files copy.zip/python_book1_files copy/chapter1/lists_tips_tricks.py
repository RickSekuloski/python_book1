# reverse the list using slicing
num_list = [3, 6, 7, 1, 5, 2, 4]
print(num_list[::-1])

# copy the list using the slicing:
num_list1 = [3, 6, 7, 1, 5, 2, 4]
new_list = num_list1[:]
print(new_list)
print(num_list1)

# create and populate numbered list
num_list2 = list(range(0, 50))
print(num_list2)

# .join()
usernames = ['andy', 'carol', 'steve', 'jason']
joined_usernames = ', '.join(usernames)
print(joined_usernames)
