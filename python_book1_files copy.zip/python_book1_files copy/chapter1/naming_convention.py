'''
variable name can contain
letters (a-Z), numbers and underscore.
It must always start with letter
'''
# valid variable names

userEmail = 'rick@gmail.com'
user_email = 'rick@gmail.com'
user_email1 = 'rick@gmail.com'
# 1user_email = 'rick@gmail.com'

# invalid variable names
_user_emailS = 'rick@gmail.com'
# 1user_email = 'rick@gmail.com'


# camel case notation
firstName = 'Jason'

# snake case notation
first_name = 'Jason'
