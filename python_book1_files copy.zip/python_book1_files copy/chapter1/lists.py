# Lists - data type
my_list = [1, 2, 3, 4, 5, 6]
my_list1 = ['a', 'b', 'c', 'd']
my_list2 = ['a', 2, 'c', 3]

print(my_list)
print(my_list1)
print(my_list2)

# individual items
print(my_list[0])
print(my_list1[1])
print(my_list2[2])
# out of range index
# print(my_list2[4])
# list type
print(type(my_list))

# length of list
print(len(my_list))

# list slicing
print(my_list[0:3])
# list slicing with stepover
my_list3 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print(my_list3[0::2])

# Lists are mutable
my_list3[0] = -1
print(my_list3)

# copy of a list
string_list = ['one', 'two', 'three']
string_list_copy = string_list[0:]
print(string_list_copy)

# mutate an element in the copied list
string_list = ['one', 'two', 'three']
string_list_copy = string_list[0:]
string_list_copy[2] = 'four'
print(string_list)
print(string_list_copy)

# create a copy using assignment operator
string_list1 = ['one', 'two', 'three']
string_list_copy1 = string_list1
print(string_list_copy1)

# in keyword with lists
string_list1 = ['one', 'two', 'three']
print('two' in string_list1)
print('five' in string_list1)
