# Constants
PI = 3.14
EARTH_GRAVITY = 9.807
print(PI)
print(EARTH_GRAVITY)

# Assign new value
PI = 3.1455
EARTH_GRAVITY = 9.8
print(PI)
print(EARTH_GRAVITY)
