
with open('file.txt', mode='r+') as new_text_file:
    content = new_text_file.write('I love Python!')
