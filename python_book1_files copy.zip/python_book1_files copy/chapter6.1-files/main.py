text_file = open('text.txt')

# text_file.seek(0)
# print(text_file.read())
# text_file.seek(1)
# print(text_file.read())
# text_file.seek(2)
# print(text_file.read())

print(text_file.readline())
print(text_file.readlines())
text_file.close()
