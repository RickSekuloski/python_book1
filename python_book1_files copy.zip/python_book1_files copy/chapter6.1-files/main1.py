# with open('text.txt', mode='r+') as new_text_file:
#     content = new_text_file.write('Hi readers!')
with open('text.txt', mode='a') as new_text_file:
    content = new_text_file.write('I love Python!')
