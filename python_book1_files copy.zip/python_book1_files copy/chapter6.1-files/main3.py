# relative path to the readme.txt file
# with open('scripts/readme.txt', mode='r') as new_text_file:
#     print(new_text_file.read())

# absolute path to the readme.txt file
# with open('/Users/rick/Desktop/chapter6.1-files/scripts/readme.txt', mode='r') as new_text_file:
#     print(new_text_file.read())

# ./ from current directory
# with open('./scripts/readme.txt', mode='r') as new_text_file:
#     print(new_text_file.read())
# one level up
with open('../scripts/readme.txt', mode='r') as new_text_file:
    print(new_text_file.read())
