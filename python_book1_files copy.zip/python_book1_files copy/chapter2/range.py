# range function
print(range(10))

# range() with for-loop
for number in range(0, 10):
    print(number)

# stepover
for _ in range(0, 10, 2):
    print(_)
