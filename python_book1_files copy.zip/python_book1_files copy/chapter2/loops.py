# for loop
# Iterate a String
for char in 'Your name is?':
    print(char)

# Iterate a List
list1 = [1, 3, 5, 7, 9]
for item in list1:
    print(item)

# Iterate over a Set
set1 = {"apple", "banana", "cherry"}
for fruit in set1:
    print(fruit)

# Iterate over a Tuple
tuple1 = ("apple", "banana", "cherry")
for fruit in tuple1:
    print(fruit)

# List of numbes
numbers = [1, 2, 4, 6, 5, 8, 11, 3, 14]

# variable to store the sum
numbers_sum = 0

for val in numbers:
    numbers_sum += val

print('The sum is: ', numbers_sum)

# nested for-loops

numbers1 = [1, 2, 3]
letters1 = ['x', 'l']

# iterate over the two lists

for val in numbers1:
    print(val)
    for letter in letters1:
        print(letter)

# nested if statements
grade = 80
if grade >= 60:
    if grade >= 90:
        print("A")

    elif grade >= 80:
        print("B")

    elif grade >= 70:
        print("C")

    elif grade >= 60:
        print("D")

else:
    print("Your grade is F")

# while loop

# calc sum up to this number
the_number = 10
# initialize sum and counter
the_sum = 0
i = 1

while i <= the_number:
    the_sum = the_sum + i
    i = i + 1  # update/increment the counter

# print the sum
print('The sum is: ', the_sum)

# break statement
i = 0
while i <= 10:
    print(i)
    if(i == 7):
        break
    i += 1
# else:
#     print('This means the while conditon is false')

# print('This line is outside the while loop')

# else clause statement
j = 0
while j <= 10:
    print(j)
    j += 1
else:
    print('This means the while conditon is false')

print('This line is outside the while loop')


# looping over a dictionary
# car dictionary
ford = {
    "brand": "Ford",
    "model": "Mustang",
    "year": 2023,
    "transmission": "Automatic"
}

for item in ford:
    print(item)

# items method
for item in ford.items():
    print(item)

# values method
for item in ford.values():
    print(item)


# keys method
for item in ford.keys():
    print(item)

# unpack the values and keys
for item in ford.items():
    key, value = item
    print(key, value)


# we can get keys & values like this
for key, value in ford.items():
    print(key, value)
