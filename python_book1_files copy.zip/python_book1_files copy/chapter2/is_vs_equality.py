print(True == 1)
# is same as
print(True == bool(1))
# is same as
print(True == True)

# 2 checking for equality
print(' ' == 1)
print(bool('') == bool(1))
print(False == True)

# is vs ==
print(True is True)
print([1, 2] is [1, 2])

list1 = [1, 2]
list2 = list1
print(list1 is list2)
list2.append(3)
print(list1)
print(list1)
