# Scope in Python
# local variabel
result = 14.4


def num_func():
    print(result)


num_func()

# function scope


def num_func1():
    num1 = 11.4
    print(num1)


num_func1()
# we cannot access the num1 outside the function scope
# print(num1)

# guess the output
x = 1


def trick_me(x):
    x = 4
    return x


print(x)
print(trick_me(5))
