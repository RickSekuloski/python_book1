# nonlocal
def outer_fn():
    x = 'John'

    def inner_fn():
        nonlocal x
        x = 'hello'
    inner_fn()
    return x


print(outer_fn())
