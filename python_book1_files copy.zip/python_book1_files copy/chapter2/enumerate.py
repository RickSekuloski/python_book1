# enumarate()
x = ('first', 'second', 'third')
y = enumerate(x)

for item in y:
    print(item)

for key, item in y:
    print(key, item)

# Strings
for key, item in enumerate('Rick'):
    print(key, item)

# Lists
for key, item in enumerate([1, 2, 3]):
    print(key, item)
