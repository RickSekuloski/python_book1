# assign =
m = 3
n = 4
x = m + n
print(x)
#Output: 7

# +=
m = 3
n = 4
m += n
print(m)
#Output: 7

# -=
m = 5
n = 3
m -= n
print(m)
#Output: 2

# multiply and assign *=
m = 5
n = 3
m *= n
print(m)
# Output: 15

# divide and assign
m = 5
n = 3
m /= n
print(m)
# Output:1.6666666666666667

# modulus and assign %=
m = 5
n = 3
m %= n
print(m)
# Output: 2

#  divide(floor) and assign //=
m = 5
n = 3
m //= n
print(m)
# Output: 1

# exponent and assign **=
m = 5
n = 3
m **= n
print(m)
# Output: 125

#  bitwise AND  assign &=
m = 5
n = 3
m &= n
print(m)
# Output: 1

# bitwise OR  assign !=
m = 5
n = 3
m |= n
print(m)
# Output: 7

# bitwise XOR and assign
m = 5
n = 3
m ^= n
print(m)
# Output:6

# bitwise right shift and assign
m = 5
n = 3
m >>= n
print(m)
# Output: 0

# bitwise left shift and assign
m = 5
n = 3
m <<= n
print(m)
# Output: 40
