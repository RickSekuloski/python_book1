# functions
def hi_function():
    print('Hi there')


# call the funciton
hi_function()

# function with one parameters


def hi_function1(name):
    print('Hi there')

# function with two parameters


def hi_function2(name, lastname):
    print('Hi there')


def hi_function3(name, lastname):
    print(f'Hi there {name}{lastname}')


hi_function3('Rick', 'Sekuloski')

# positional arguments


def hi_function4(name, lastname, age):
    print(f'Hi there {name}{lastname}. Are you {age} old?')


hi_function4('Rick', 'Sekuloski', 33)


# keyword arguments


def hi_function5(name, lastname, age):
    print(f'Hi there {name}{lastname}. Are you {age} old?')


hi_function5(name='Rick', lastname='Sekuloski', age=33)
hi_function5(name='Rick',  age=33, lastname='Sekuloski')
