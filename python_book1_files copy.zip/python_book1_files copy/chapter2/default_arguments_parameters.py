# name, lastname are parameters

def hi_function6(name='John', lastname='Doe', age=30):
    print(f'Hi there {name} {lastname}. Are you {age} old?')


hi_function6('Novak', 'Djokovic', 40)
# the default argument will replace the missing age
hi_function6('Novak', 'Djokovic')

# sum function with return keyword


def calc_fun(num1, num2):
    return num1 + num2


# print(calc_fun(3, 4))
fn_result = calc_fun(3, 4)
fn_result += 1
print(fn_result)
