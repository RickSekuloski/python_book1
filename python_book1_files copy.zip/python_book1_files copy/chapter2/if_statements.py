# If statements

is_developer = True
if is_developer:
    print('Wow this must be super exciting!')
print('New line')

# if-else
is_developer = False
if is_developer:
    print('Wow this must be super exciting!')
else:
    print('What is your profession then?')

# elif
is_developer = False
is_employed = True
if is_developer:
    print('Wow this must be super exciting!')
elif is_employed:
    print('Great at least you have a job :)')
else:
    print('What is your profession then?')

# if-else with different conditon
x = 10

if x > 11:
    print('The value of x is smaller then 11')
elif x > 5:
    print('The value of x is bigger than 5')
else:
    print('The value of x is undefined')
