# Comparison Operators
x = 4
y = 3

# == equal
print(x == y)
# Output False

# > greather than
print(x > y)
# Output True

# < less than
print(x < y)
# Output False

# >= greater than or eqaul to
print(x >= y)
# Output True


# >= less than or eqaul to
print(x <= y)
# Output False

# != Not Equal
print(x != y)
# Output True
