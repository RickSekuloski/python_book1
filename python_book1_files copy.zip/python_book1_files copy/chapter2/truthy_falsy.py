# Truthy vs Falsy
if 6 > 4:
    print("True")
else:
    print("False")

#
m = 10
if m:
    print("True")
else:
    print("False")

# falsy
n = 0
s = ''
print(bool(n))
print(bool(s))
print(bool(False))
print(bool(None))
print(bool([]))
print(bool({}))
print(bool(()))


# user registration
username = 'rick'
password = ''
email = 'rick@gmail.com'

if username and password and email:
    print('All of the data is filled in correctly')
else:
    print('Some of the fields  are empty, we can\'t register you')
