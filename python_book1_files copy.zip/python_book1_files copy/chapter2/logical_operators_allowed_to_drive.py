my_age = 16
is_licenced = True
if is_licenced and my_age >= 16:
    print('Hop on for a ride')
else:
    print('Sorry buddy, I\'m driving today!')
