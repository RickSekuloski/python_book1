# Break, continue and pass statements
brands = ["ford", "bmw", "toyota", "audi", "mercedes"]
for brand in brands:
    print(brand)
    if brand == 'toyota':
        break
print('If you read this line the loop is finished')

# continue
for brand in brands:
    if brand == 'bmw':
        continue
    print(brand)
print('If you read this line the loop is finished')


# pass
is_old = True
if is_old:
    # no code
    pass
print('This will give us an error')
