# args and kwargs
def years_old(curr, dob):
    return curr - dob


age = years_old(2022, 1999)
# age = years_old(2022, 1999, 2019)
print(age)


# args and kwargs
def addition_fn(*args):
    return sum(args)


result = addition_fn(1, 2, 3, 4, 5, 6)
print(result)


# args and kwargs
def addition_fn1(*args, **kwargs):
    result = 0
    for item in kwargs.values():
        result += item
    return sum(args) + result


result1 = addition_fn1(1, 2, 3, 4, 5, 6, n7=7, n8=8)
print(result1)
