# identity operators

# is
a = ["apple"]
b = ["apple"]
c = a
print(a is c)
# this returns true because a is same object as c
print(a is b)
# this returns false because a is not same as object b
print(a == b)
# this returns true because the content of a is same as the content of object b

# is not
a = ["apple"]
b = ["apple"]
c = a

print(a is not c)
# this returns false because a is the same as object  c

print(a is not b)
# this will return true because object a is not same as the object as b even if they have the same content/values

print(a != b)
# The comparison operator != will return false because a is equal to b
