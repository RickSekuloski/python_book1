# chapter-2 exercise
dirty_list = [1, 2, 3, 2, 4, 1, 5, 6, 5, 5, 7, 8, 1, 9, 10, 9, 8, 3]
# empty list
clean_list = []
# loop over the items
for item in dirty_list:
    # check if the item doesn't exist in the list
    if item not in clean_list:
        # if item is not found then add it
        clean_list.append(item)

print(clean_list)
