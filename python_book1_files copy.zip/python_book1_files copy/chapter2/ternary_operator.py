# ternary operator
is_old = True
is_allowed = "You can drink tonight" if is_old else "You cannot drink tonight coz of your age"
print(is_allowed)
