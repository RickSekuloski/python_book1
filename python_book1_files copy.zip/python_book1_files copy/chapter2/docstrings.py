# docstrings
def num_square(num):
    '''This function takes a number and returns the square of that number'''
    return num**2


result = num_square(4)
print(result)

# help to read about the function
help(num_square)
help(len)
# using dunder methods
print(num_square.__doc__)
