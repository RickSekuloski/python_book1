# dictionary
dict_obj = {
    "type": "1"
}
print(dir(dict_obj))

# list
list_obj = [1, 3, 5, 7, 9]
print(len(list_obj))


# car class

class Car(object):
    def __init__(self, color, make, year, size):
        self.color = color
        self.make = make
        self.year = year
        self.size = size
        self.engine_dict = {
            'automatic': 'Yes',
            'manual': 'No'
        }

    # modify the dunder str method
    def __str__(self):
        return f'{self.make}'

    # modify the dunder del method
    def __del__(self):
        print('Deleted')

    # Calling __delete__
    def __delete__(self, instance):
        print("Inside is delete!")

    # call method
    def __call__(self):
        return 'Called!'

    # create the __getitem__ method
    def __getitem__(self, index):
        return self.engine_dict[index]


bmw_car = Car('red', 'bmw', 2022, 'sedan')

# call the dunder __str__ method:
print(bmw_car.__str__())

# the exact same as above is the built-in str() function
print(str(bmw_car))

# call the bmw_car object
print(bmw_car())
# call the bmw_car instance using the square brackets
print(bmw_car['manual'])
# call the del method
del bmw_car

# if we try to access the bmw_car object an error
# print(bmw_car)
