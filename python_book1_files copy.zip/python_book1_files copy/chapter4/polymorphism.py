# polymorphism
print('******** len() function polymorphism example! ********')
str_obj = "Polymorphism"
list_obj = ["Java", "Python", "Ruby", "C#", "PHP", "C++"]
dict_obj = {
  "brand": "Tesla",
  "model": "Funny names :)",
  "year": 2023
}
print(len(str_obj))
print(len(list_obj))
print(len(dict_obj))
