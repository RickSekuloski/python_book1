class Person:
    # Class Object Attributes
    is_person = True

    # Constructor
    def __init__(self, name, lastname, age):
        if age >= 18:
            self.name = name  # name attribute
            self.lastname = lastname  # lastname attribute
            self.age = age  # age attribute

    # Method
    def greet(self):
        print(f'{self.name}, '
              f'{self.lastname}, old: {self.age}. '
              f'Called by the class itself: {Person.is_person}. '
              f'Called by the self keyword {self.is_person}')

# the object will not be created because of if-condition
# person_obj1 = Person('Jason', 'Brooks', 17)
# print(person_obj1.greet())
person_obj2 = Person('Andy', 'Garcia', 20)
print(person_obj2.greet())

