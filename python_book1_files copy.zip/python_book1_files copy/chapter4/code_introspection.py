# code introspection


# 1 type()
str_obj = 'Hi'
list_obj = [1, 5, 7]
int_obj = 10
float_obj = 10.3
dict_obj = {
    "type": "1"
}

print(type(str_obj))
print(type(list_obj))
print(type(int_obj))
print(type(float_obj))
print(type(dict_obj))

# 2 dir()
print(dir(dict_obj))

# 3 str()
list_obj1 = [1, 2, 4]
print(type(list_obj1))
# convert to str
print(type(str(list_obj1)))

# 4 id()
m = [1, 2, 3, 4, 5]

# print id of m
print(id(m))
