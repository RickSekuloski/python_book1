# class template
class StudentObj:
    pass

# Create new object by instantiating the StudentObj class
s_obj1 = StudentObj()

print(type(s_obj1))
