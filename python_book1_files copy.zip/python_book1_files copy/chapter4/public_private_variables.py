# private and public variables
class Person:
    # Constructor
    def __init__(self, name='John', lastname='Doe', age=18):
        if age >= 18:
            self.name = name
            self._lastname = lastname # private variable
            self.age = age

    # Class method
    def greet(self):
        print(f'The data and functions are encapsulated, \n'
              f'My name is: {self.name}, \n'
              f'My last name is: {self._lastname}, \n'
              f'and I\'m {self.age} old.')


person_obj1 = Person('Jason', 'Mamoa', 53)
person_obj1.greet()
person_obj1._lastname = 'Bourne'
print('-------------------')
person_obj1.greet()

