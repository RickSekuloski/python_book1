class Person:
    # Constructor
    def __init__(self, name, lastname, age):
        self.name = name
        self.lastname = lastname
        self.age = age

    # Class method
    def greet(self):
        print(f'{self.name}, '
              f'{self.lastname}, old: {self.age}')


person_obj1 = Person('Jason', 'Brooks', 44)
print(person_obj1.greet())

