# MRO - Method Resolution Order

# class A

class A:
    def __init__(self, length=5):
        self.length = length

    def info(self):
        return self.length


class B(A):
    pass


class C(A):
    def __init__(self, length=2):
        self.length = length

    def info(self):
        return self.length


class D(B, C):
    pass


# instance of class D
d_ob1 = D()
print(d_ob1.info())

# show the order
print(D.mro())