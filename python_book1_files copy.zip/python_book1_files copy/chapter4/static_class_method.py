class Person:
    # Class Object Attributes
    is_person = True

    # Constructor
    def __init__(self, name, lastname, age):
        if age >= 18:
            self.name = name  # name attribute
            self.lastname = lastname  # lastname attribute
            self.age = age  # age attribute

    # Class Method
    @classmethod
    def date_created(cls, today_date, year):
        print(today_date, year)

    # Static Method
    @staticmethod
    def is_adult(age):
        return age >= 18

    # Method
    def greet(self):
        print(f'{self.name}, '
              f'{self.lastname}, old: {self.age}. '
              f'Called by the class itself: {Person.is_person}. '
              f'Called by the self keyword {self.is_person}')



person_obj4 = Person('Andy', 'Garcia', 20)
print(person_obj4.greet())

print(Person.is_adult(19))

